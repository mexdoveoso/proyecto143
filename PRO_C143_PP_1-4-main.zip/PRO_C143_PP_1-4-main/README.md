# PRO_C143_PP_1-4
## product_dataset
Productos: smartphones y celulares, cámaras digitales, audífonos y videojuegos.

